// src/grid/Grid.ts

import { GridRenderer } from "./GridRenderer";
import { GridDataStore } from "../data/GridDataStore";
import { ViewportManager } from "../viewort/ViewportManager";
import { SelectionManager } from "../selection/SelectionManager";
import { EditManager } from "../edit/EditManager";
import { Summary } from "../summary/Summary";
import { CommandManager } from "../commands/CommandManager";
export class Grid {

    private canvas: HTMLCanvasElement;
    private context: CanvasRenderingContext2D;

    private renderer: GridRenderer;
    private dataStore: GridDataStore;
    private viewport: ViewportManager;
    private selection: SelectionManager;
    private editor: EditManager;
    private commandManager: CommandManager;
    private summaryCalculator: SummaryCalculator;

    private width: number;
    private height: number;

    constructor(canvas: HTMLCanvasElement) {

        this.canvas = canvas;

        const ctx = canvas.getContext("2d");

        if (!ctx) {
            throw new Error("Canvas Context Not Supported");
        }

        this.context = ctx;

        this.width = canvas.width;
        this.height = canvas.height;

        this.dataStore = new GridDataStore();

        this.viewport = new ViewportManager(
            this.width,
            this.height
        );

        this.selection = new SelectionManager();

        this.commandManager = new CommandManager();

        this.summaryCalculator = new SummaryCalculator(
            this.dataStore,
            this.selection
        );

        this.editor = new EditManager(
            this.dataStore,
            this.selection,
            this.commandManager
        );

        this.renderer = new GridRenderer(
            this.context,
            this.dataStore,
            this.viewport,
            this.selection
        );

        this.initialize();
    }

    private initialize(): void {

        this.registerEvents();

        this.render();
    }

    public render(): void {

        this.renderer.render();

        this.updateSummary();
    }

    private updateSummary(): void {

        this.summaryCalculator.calculate();
    }



private registerEvents(): void {

        this.canvas.addEventListener("mousedown", this.handleMouseDown);

        this.canvas.addEventListener("mousemove", this.handleMouseMove);

        window.addEventListener("mouseup", this.handleMouseUp);

        this.canvas.addEventListener("dblclick", this.handleDoubleClick);

        this.canvas.addEventListener("wheel", this.handleWheel, {
            passive: false,
        });

        window.addEventListener("keydown", this.handleKeyDown);

        window.addEventListener("resize", this.handleResize);
    }

    private handleMouseDown = (event: MouseEvent): void => {

        const x = event.offsetX;
        const y = event.offsetY;

        this.selection.startSelection(x, y, this.viewport);

        this.render();
    };

    private handleMouseMove = (event: MouseEvent): void => {

        const x = event.offsetX;
        const y = event.offsetY;

        if (this.selection.isSelecting()) {

            this.selection.updateSelection(
                x,
                y,
                this.viewport
            );

            this.render();
        }
    };

    private handleMouseUp = (): void => {

        this.selection.finishSelection();

        this.render();
    };

    private handleDoubleClick = (event: MouseEvent): void => {

        const x = event.offsetX;
        const y = event.offsetY;

        this.editor.beginEdit(
            x,
            y,
            this.viewport,
            () => {

                this.render();
            }
        );
    };

    private handleWheel = (event: WheelEvent): void => {

        event.preventDefault();

        this.viewport.scroll(
            event.deltaX,
            event.deltaY
        );

        this.render();
    };

    private handleResize = (): void => {

        this.width = this.canvas.clientWidth;
        this.height = this.canvas.clientHeight;

        this.canvas.width = this.width;
        this.canvas.height = this.height;

        this.viewport.setViewportSize(
            this.width,
            this.height
        );

        this.render();
    };

    private handleKeyDown = (event: KeyboardEvent): void {

        if (event.ctrlKey && event.key.toLowerCase() === "z") {

            event.preventDefault();

            this.commandManager.undo();

            this.render();

            return;
        }

        if (event.ctrlKey && event.key.toLowerCase() === "y") {

            event.preventDefault();

            this.commandManager.redo();

            this.render();

            return;
        }

        if (event.key === "ArrowUp") {

            this.selection.moveUp();

            this.render();

            return;
        }

        if (event.key === "ArrowDown") {

            this.selection.moveDown();

            this.render();

            return;
        }

        if (event.key === "ArrowLeft") {

            this.selection.moveLeft();

            this.render();

            return;
        }

        if (event.key === "ArrowRight") {

            this.selection.moveRight();

            this.render();

            return;
        }

        if (event.key === "Enter") {

            this.editor.editSelectedCell(() => {

                this.render();

            });

            return;
        }

        if (event.key === "Escape") {

            this.editor.cancelEditing();

            this.render();
        }


}

    public loadData(data: Record<string, unknown>[]): void {

        this.dataStore.loadData(data);

        this.viewport.reset();

        this.render();
    }

    public refresh(): void {

        this.render();
    }

    public resize(width: number, height: number): void {

        this.width = width;
        this.height = height;

        this.canvas.width = width;
        this.canvas.height = height;

        this.viewport.setViewportSize(width, height);

        this.render();
    }

    public getSelectionManager(): SelectionManager {

        return this.selection;
    }

    public getCommandManager(): CommandManager {

        return this.commandManager;
    }

    public getDataStore(): GridDataStore {

        return this.dataStore;
    }

    public getViewportManager(): ViewportManager {

        return this.viewport;
    }

    public getEditManager(): EditManager {

        return this.editor;
    }

    public destroy(): void {

        this.canvas.removeEventListener(
            "mousedown",
            this.handleMouseDown
        );

        this.canvas.removeEventListener(
            "mousemove",
            this.handleMouseMove
        );

        window.removeEventListener(
            "mouseup",
            this.handleMouseUp
        );

        this.canvas.removeEventListener(
            "dblclick",
            this.handleDoubleClick
        );

        this.canvas.removeEventListener(
            "wheel",
            this.handleWheel
        );

        window.removeEventListener(
            "keydown",
            this.handleKeyDown
        );

        window.removeEventListener(
            "resize",
            this.handleResize
        );
    }
}
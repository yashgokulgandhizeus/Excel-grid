// src/grid/GridRenderer.ts

import { GridDataStore } from "../data/GridDataStore";
import { ViewportManager } from "../viewport/ViewportManager";
import { SelectionManager } from "../selection/SelectionManager";

export class GridRenderer {

    private context: CanvasRenderingContext2D;

    private dataStore: GridDataStore;

    private viewport: ViewportManager;

    private selection: SelectionManager;

    constructor(
        context: CanvasRenderingContext2D,
        dataStore: GridDataStore,
        viewport: ViewportManager,
        selection: SelectionManager
    ) {

        this.context = context;
        this.dataStore = dataStore;
        this.viewport = viewport;
        this.selection = selection;
    }

    public render(): void {

        this.clearCanvas();

        this.drawColumnHeaders();

        this.drawRowHeaders();

        this.drawCells();

        this.drawSelection();

        this.drawGridLines();
    }

    private clearCanvas(): void {

        this.context.clearRect(
            0,
            0,
            this.viewport.getViewportWidth(),
            this.viewport.getViewportHeight()
        );

        this.context.fillStyle = "#ffffff";

        this.context.fillRect(
            0,
            0,
            this.viewport.getViewportWidth(),
            this.viewport.getViewportHeight()
        );
    }

    private drawColumnHeaders(): void {

        const columns = this.viewport.getVisibleColumns();

        this.context.fillStyle = "#f3f3f3";
        this.context.strokeStyle = "#d0d0d0";
        this.context.font = "14px Arial";
        this.context.textBaseline = "middle";

        for (const column of columns) {

            this.context.fillRect(
                column.x,
                0,
                column.width,
                this.viewport.getHeaderHeight()
            );

            this.context.strokeRect(
                column.x,
                0,
                column.width,
                this.viewport.getHeaderHeight()
            );

            this.context.fillStyle = "#000000";

            this.context.fillText(
                column.label,
                column.x + 8,
                this.viewport.getHeaderHeight() / 2
            );

            this.context.fillStyle = "#f3f3f3";
        }
    }

    private drawRowHeaders(): void {

        const rows = this.viewport.getVisibleRows();

        this.context.fillStyle = "#f3f3f3";
        this.context.strokeStyle = "#d0d0d0";

        for (const row of rows) {

            this.context.fillRect(
                0,
                row.y,
                this.viewport.getHeaderWidth(),
                row.height
            );

            this.context.strokeRect(
                0,
                row.y,
                this.viewport.getHeaderWidth(),
                row.height
            );

            this.context.fillStyle = "#000000";

            this.context.fillText(
                String(row.index + 1),
                8,
                row.y + row.height / 2
            );

            this.context.fillStyle = "#f3f3f3";
        }
    }
private drawCells(): void {

        const visibleRows = this.viewport.getVisibleRows();
        const visibleColumns = this.viewport.getVisibleColumns();

        this.context.font = "14px Arial";
        this.context.textBaseline = "middle";

        for (const row of visibleRows) {

            for (const column of visibleColumns) {

                const value = this.dataStore.getCellValue(
                    row.index,
                    column.index
                );

                this.context.fillStyle = "#ffffff";

                this.context.fillRect(
                    column.x,
                    row.y,
                    column.width,
                    row.height
                );

                this.context.strokeStyle = "#e0e0e0";

                this.context.strokeRect(
                    column.x,
                    row.y,
                    column.width,
                    row.height
                );

                if (
                    value === undefined ||
                    value === null ||
                    value === ""
                ) {
                    continue;
                }

                this.context.save();

                this.context.beginPath();

                this.context.rect(
                    column.x + 2,
                    row.y + 2,
                    column.width - 4,
                    row.height - 4
                );

                this.context.clip();

                this.context.fillStyle = "#000000";

                this.context.fillText(
                    String(value),
                    column.x + 6,
                    row.y + row.height / 2
                );

                this.context.restore();
            }
        }
    }

    private drawGridLines(): void {

        const rows = this.viewport.getVisibleRows();
        const columns = this.viewport.getVisibleColumns();

        this.context.beginPath();

        this.context.strokeStyle = "#d9d9d9";

        for (const column of columns) {

            this.context.moveTo(column.x, 0);

            this.context.lineTo(
                column.x,
                this.viewport.getViewportHeight()
            );
        }

        for (const row of rows) {

            this.context.moveTo(0, row.y);

            this.context.lineTo(
                this.viewport.getViewportWidth(),
                row.y
            );
        }

        this.context.stroke();
    }
private drawSelection(): void {

        const range = this.selection.getSelectedRange();

        if (!range) {
            return;
        }

        const startCell = this.viewport.getCellBounds(
            range.startRow,
            range.startColumn
        );

        const endCell = this.viewport.getCellBounds(
            range.endRow,
            range.endColumn
        );

        if (!startCell || !endCell) {
            return;
        }

        const x = Math.min(startCell.x, endCell.x);
        const y = Math.min(startCell.y, endCell.y);

        const width =
            Math.abs(
                (endCell.x + endCell.width) - startCell.x
            );

        const height =
            Math.abs(
                (endCell.y + endCell.height) - startCell.y
            );

        this.context.save();

        this.context.fillStyle = "rgba(33,115,70,0.15)";

        this.context.fillRect(
            x,
            y,
            width,
            height
        );

        this.context.strokeStyle = "#217346";

        this.context.lineWidth = 2;

        this.context.strokeRect(
            x,
            y,
            width,
            height
        );

        this.context.restore();

        this.drawActiveCell(startCell);
    }

    private drawActiveCell(cell: {
        x: number;
        y: number;
        width: number;
        height: number;
    }): void {

        this.context.save();

        this.context.strokeStyle = "#107c41";

        this.context.lineWidth = 2;

        this.context.strokeRect(
            cell.x,
            cell.y,
            cell.width,
            cell.height
        );

        this.context.fillStyle = "#107c41";

        this.context.fillRect(
            cell.x + cell.width - 4,
            cell.y + cell.height - 4,
            6,
            6
        );

        this.context.restore();
    }

    private drawResizeIndicator(
        x: number,
        y: number,
        width: number,
        height: number
    ): void {

        this.context.save();

        this.context.strokeStyle = "#4a90e2";

        this.context.setLineDash([4, 2]);

        this.context.strokeRect(
            x,
            y,
            width,
            height
        );

        this.context.restore();
    }
}